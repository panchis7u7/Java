package prii_u207_ventanasmdi;
/**
 * @author Katherine Arzate Serrano
 * @author Carlos Sebastian Madrigal Rodriguez
 */
public class Programa {

    static void main(String[] args) {
        // TODO code application logic here
        VentanaPadre v = new VentanaPadre();
        v.setLocationRelativeTo(null);
        v.setTitle("Ordenes de trabajo");
        v.setVisible(true);
    }
    
}
